package Assignment_2_Exs_03_7;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class Person {
	private String fname;
	private String lname;
	private char gender;
	
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}

	
	public void calculateAge(){
		DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd/MM/yyyy");
		System.out.println("Enter date in dd/MM/yyyy format");
		@SuppressWarnings("resource")
		Scanner sc= new Scanner(System.in);
		String dateString=sc.next();
		 LocalDate date = LocalDate.parse(dateString, formatter);
		 LocalDate localdate= LocalDate.now();
		
		Period period =Period.between(date,localdate);
		System.out.println(" Age:"+Math.abs(period.getYears()));
		
	}
	public String getFullName(String fname,String lname)
	{
		return fname.concat(lname);
		
	}
	}

