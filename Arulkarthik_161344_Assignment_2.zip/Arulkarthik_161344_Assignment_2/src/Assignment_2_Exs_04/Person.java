package Assignment_2_Exs_04;

public class Person extends Account {
	private String name;
	private float age;
	
	public String getName() {
		return name;
    }
	
	public void setName(String name) {
		this.name = name;
	
	}
	
	public float getAge() {
		return age;
	}
	
	public void setAge(float age) {
		this.age = age;
	}
	
	public Person(long accnum, double balance, String name, float age) {
	super(accnum, balance);
		this.age = age;
		this.name= name;
	}
@Override
public String toString()
{ return "Your account details are: "+name +" "+age+" "+ getAccnum()+" "+getBalance();
	}
	public static void main(String[] args) {
		Person p1= new Person(1234, 2000,  "Smith", 25);
		Person p2 = new Person(5678, 3000, "Kathy", 22);
		p1.setAccholder(p1);
		p2.setAccholder(p2);
		
		p1.deposit(2000);
		p2.withDraw(2000);
		
		System.out.println("Smith's balance: "+ p1.getBalance());
		System.out.println("Kathy's balance: "+ p2.getBalance());
		System.out.println(p1);
	}


}
