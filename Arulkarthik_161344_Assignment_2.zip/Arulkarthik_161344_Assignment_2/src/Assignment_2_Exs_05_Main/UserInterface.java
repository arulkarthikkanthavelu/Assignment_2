package Assignment_2_Exs_05_Main;

import java.util.Scanner;

import Assignment_2_Exs_05_Bean.Employee;
import Assignment_2_Exs_05_service.IEmployeeService;
import Assignment_2_Exs_05_service.InsuranceService;

public class UserInterface {
public static void main(String[] args) {
	Assignment_2_Exs_05_Bean.Employee emp= new Assignment_2_Exs_05_Bean.Employee();
	IEmployeeService service = new InsuranceService();
	@SuppressWarnings("resource")
	Scanner sc = new Scanner (System.in);
	
	System.out.println("Enter employee ID ");
	int ID = sc.nextInt();
	
	System.out.println("Enter employee name:");
	String name = sc.next();
	
	 System.out.println("Enter salary:");
	 long salary= sc.nextLong();
			 
	 System.out.println("Enter designation ");
	 String designation = sc.next();
	 
	 emp.setId(ID);
	 emp.setName(name);
	 emp.setSalary(salary);
	 emp.setDesignation(designation);
	
	System.out.println(service.getInsuranceScheme(emp)); 
}
}
