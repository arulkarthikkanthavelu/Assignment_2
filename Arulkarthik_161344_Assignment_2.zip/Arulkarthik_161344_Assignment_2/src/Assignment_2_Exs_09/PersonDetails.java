package Assignment_2_Exs_09;

import java.util.Scanner;



public class PersonDetails {
	 private String f_name;
	 private String l_name;
	 private char gen;
	 private int age;
	 private double wht;
	 private String phno;
	 public String getF_name() {
			return f_name;
		}

		public void setF_name(String f_name) {
			this.f_name = f_name;
		}

		public String getL_name() {
			return l_name;
		}

		public void setL_name(String l_name) {
			this.l_name = l_name;
		}

		public char getGen() {
			return gen;
		}

		public void setGen(char gen) {
			this.gen = gen;
		}

		public int getAge() {
			return age;
		}

		public void setAge(int age) {
			this.age = age;
		}

		public double getWht() {
			return wht;
		}

		public void setWht(double wht) {
			this.wht = wht;
		}



		public String getPhno() {
			
			return phno;
		}

		public String setPhno() {
			Scanner sc= new Scanner(System.in);
			phno= sc.next();
			return phno;
		}

		public void dispDetails(){
			System.out.println("First Name:" +f_name);
			System.out.println("Last Name:" +l_name);
			System.out.println("Gender:" +gen);
			System.out.println("Age:" +age);
			System.out.println("Weight:" +wht);
			System.out.println("Phone no:" +phno);
			
			
		}
		//default constructor
		public PersonDetails()
		{
			f_name= "Saurabh";
		 l_name= "Srivastava";
		 gen= 'M';
		 age = 22;
		 wht = 76.50; 
		 phno = "7053855190";
		 
		 
		}
		//parameterized constructor
		public PersonDetails(String f_name, String l_name, char gen, int age, double wht, String phno) {
			super();
			this.f_name = f_name;
			this.l_name = l_name;
			this.gen = gen;
			this.age = age;
			this.wht = wht;
			this.phno = phno;
		}

		public static void main(String[] args) {
			PersonDetails p1= new PersonDetails();
			System.out.println("Enter the Phone No:");
			p1.setPhno();
			
	p1.dispDetails();
			
		}}
