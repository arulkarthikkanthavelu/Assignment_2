package Assignment_2_Exs_06_2;
import java.util.Scanner;


public class Person {
		private String name;
		private float age;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public float getAge() {
			try{
				Scanner input=new Scanner(System.in);
				System.out.println("enter the age");
				age=input.nextFloat();
				if (age<15)
				{
					throw new Exception();
				}
				else
				{
					System.out.println("age:"+age);
				}
			}
			catch(Exception e)
			{
				System.out.println("given age is less than 15");
			}
			return age;
		}
		public void setAge(float age) {
			this.age = age;
		}
		public String toString()
		{
			return name+" and "+age;
		}


		}

